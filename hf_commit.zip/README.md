---
license: cc-by-4.0
language:
- en
task_categories:
- text-classification
tags:
- safety
- content-moderation
- slang
- youth-language
- benchmark
size_categories:
- n<1K
configs:
- config_name: default
  data_files:
  - split: train
    path: Gen_Alpha_Benchmark_v7_4_2.csv
- config_name: baseline_v7
  data_files:
  - split: train
    path: "Gen Alpha Baseline - V7.csv"
---

# GenAlphaBench

A safety-annotated benchmark of 239 Generation Alpha (born 2010–2024) expressions for
evaluating LLM comprehension and safety assessment of youth digital language. Each
expression is annotated across 24 fields: a six-category risk taxonomy (R0 neutral
through R5 cultural variant), platform contexts, community origin, temporal metadata
(origin, mainstream adoption, decline, staleness), and usage examples.

**Canonical file: `Gen_Alpha_Benchmark_v7_4_2.csv`** (see `CHANGELOG.md`). Earlier versions are retained: `Gen_Alpha_Benchmark_v7_4_1.csv` (pre multi-label conversion) and the baseline below.

`Gen Alpha Baseline - V7.csv` is retained for provenance: it is the version the paper's
model evaluations were run against. It differs from the canonical file at ids 220 and 232,
where two expressions were substituted, and lacks the two added columns:

- `origin_sources` — documentary sources supporting each community-origin label
  (format `type:URL | type:URL`); the full audit trail with per-source evidence notes
  is in `origin_sources_audit.csv`
- `attribution_basis` — `documentary` (two independent sources), `documentary_single`
  (one), or `informant` (native-speaker attestation by the Gen Alpha member of the
  research team)

In v7.4.1, nine community-origin labels were re-coded to `none` after a documentary audit
found no supporting attribution or documented alternative origins; prior labels are
preserved in the audit file. In v7.4.2, sixteen expressions whose audited sources attribute
origin to Black queer, drag, or ballroom culture were re-coded to the joint `AAVE/LGBTQ+`
value; expressions whose documented lineage is not through Black vernacular (e.g. "twink",
"fruity") remain single-label.

## Content notice

The dataset documents coded slurs, suicide-baiting language, sexual euphemisms, and
references to violence, included for the purpose of evaluating detection capabilities.
Community-origin labels exist for bias auditing only. Not intended for: training
harmful-content generators, differential moderation by community origin, or
surveillance of youth communication.

## Collection

Expressions were identified through observation of publicly circulating vocabulary and
verified against public documentation (Know Your Meme, slang lexicography, dated news
coverage, Google Trends). The dataset contains no user posts, quotations, usernames,
or personal data; usage examples are composed by the research team. Risk labels were
validated by a cohort of 24 Gen Alpha participants (ages 11–14, parental consent,
κ = 0.81); label disagreements were resolved by expert review.

## Evaluation code and leaderboard

https://github.com/SystemTwoAI/GenAlphaSlang — verbatim prompts, scoring pipeline,
validation scripts, and a public model leaderboard under a pinned LLM-judge protocol.
