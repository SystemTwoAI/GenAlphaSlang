# Dataset v7.4.2

- Multi-label community-origin conversion: 16 expressions whose audited sources attribute
  origin to Black queer/drag/ballroom culture re-coded from single-label (AAVE or LGBTQ+)
  to the joint AAVE/LGBTQ+ value, joining the 2 items already so coded. The re-coding is
  evidence-driven: only rows whose recorded origin_sources name both lineages were changed.
  Deliberately unchanged: "twink" (documented US gay slang, 1960s) and "fruity" (Polari
  lineage), whose records do not indicate AAVE origin.
- No other fields changed from v7.4.1.

# Dataset v7.4.1 — 2026-07-23

- Added `origin_sources`: per-expression documentary sources supporting community-origin labels (format `type:URL | type:URL`). 60 expressions carry two independent sources; 7 carry one.
- Added `attribution_basis`: `documentary` (two sources), `documentary_single` (one source), `informant` (native-speaker attestation by the Gen Alpha informant on the research team; 3 expressions: ids 87, 234, 238).
- Re-coded `minority_community_origin` to `none` for 9 expressions where a documentary audit found no supporting attribution or found documented alternative origins (ids 21, 74, 76, 79, 112, 133, 175, 178, 190). Prior labels are preserved in the audit file. Per Appendix C.2, origin is null when uncertain.
- No risk-category, meaning, or temporal fields were changed.
- Known issue carried over: ids 220 and 232 differ in surface form from the evaluated benchmark version (see paper).
